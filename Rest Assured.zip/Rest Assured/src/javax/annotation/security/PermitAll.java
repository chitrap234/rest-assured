package javax.annotation.security;

public enum PermitAll {

}
