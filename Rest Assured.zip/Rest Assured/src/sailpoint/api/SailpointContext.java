package sailpoint.api;

public @interface SailpointContext {

}
